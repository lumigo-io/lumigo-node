#!/usr/bin/env bash
pushd ..
rm -rf lumigo-node-d_exmaple.tgz || true
npm run build
tracer="$(npm pack)"
mv $tracer lumigo-node-d_exmaple.tgz
popd
rm -rf package-lock.json
rm -rf node_modules
npm i
rm -rf dist/

# When un comment: add
#    "webpack": "^4.44.1",
#    "webpack-cli": "^3.3.12"
# To package json
#npx webpack --no-cache
sls deploy --force