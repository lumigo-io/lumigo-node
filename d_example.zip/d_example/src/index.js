/* eslint-disable no-console */
// const monitorToken = 't_867e2f98aac949d989da1';
const { promisify } = require('util');

const efiToken = 't_d6f46ac4b1e5414ab413e';
const monitorEnv = {
  token: 't_867e2f98aac949d989da1',
  edgeHost: 'tracer-edge.internal-monitoring.golumigo.com',
};
// const epsagon = require('epsagon');
// epsagon.init({
//   token: 'DummyToken',
//   appName: 'DummyApp',
//   metadataOnly: false,
// });
const doriEnv = {
  token: 't_578ff9b24a28ef76beb4',
  edgeHost: 'onxjcisrfe.execute-api.us-west-2.amazonaws.com',
};

const edgeHost = 'edge-tracer-test.free.beeceptor.com';

const lumigoLib = require('@lumigo/tracer');
const lumigo = lumigoLib({ ...monitorEnv, debug: true });

const beeceptorUrl = 'https://test-tracer-1.free.beeceptor.com';
// const AWS = require('aws-sdk');

// const xrayCloudWatch = async () => {
//   const event = {
//     // Event envelope fields
//     Source: 'custom.myATMapp',
//     EventBusName: 'test-event-bus',
//     DetailType: 'transaction',
//     Time: new Date(),
//
//     // Main event body
//     Detail: JSON.stringify({
//       action: 'withdrawal',
//     }),
//   };
//
//   const params = { Entries: [event] };
//
//   const eventBridge = new AWS.EventBridge({ region: 'us-east-1' });
//   await eventBridge.putEvents(params).promise();
// };

// const axiosRequest = async () => {
//   const axios = require('axios');
//   const axiosRetry = require('axios-retry');
//   axiosRetry(axios, { retries: 15 });
//   await axios.post(beeceptorUrl, {
//     firstName: 'Fred',
//     lastName: 'Flintstone',
//   });
// };

const dynamoDbRequests = async (count = 4000) => {
  const AWS = require('aws-sdk');
  const dynamodb = new AWS.DynamoDB();
  const dynamoRequests = count;
  const promises = [];
  for (let i = 0; i < dynamoRequests; i++) {
    const promise = dynamodb.listTables().promise();
    promises.push(promise);
  }
  await Promise.all(promises);
};

// const httpCallRequest = async () => {
//   const { HTTP } = require('http-call');
//   const requestData = { lumigo: '1234' };
//   const headers = { lumigoHeader: '4321' };
//   console.log('START GET');
//   await HTTP.get(`${beeceptorUrl}/hello?lumigo=1234`, { headers: headers });
//   console.log('START POST');
//   await HTTP.post(`${beeceptorUrl}/world`, {
//     headers: headers,
//     body: requestData,
//   });
// };

// const mongoQuery = async () => {
//   const mongoose = require('mongoose');
//
//   await mongoose.connect(
//     'mongodb+srv://tracer-test-user:Az123456@tracertestcluster.csc7x.mongodb.net/TracerDB',
//     { useUnifiedTopology: true }
//   );
//
//   const UserModel = mongoose.model('Users', new mongoose.Schema({ name: String }));
//
//   const userDoc = new UserModel({ name: 'Foo' });
//   await userDoc.save();
//
//   const userFromDb = await UserModel.findOne({ name: 'Foo' });
//   console.log(userFromDb);
// };

// const randomId = () => {
//   let result = '';
//   const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//   const charactersLength = characters.length;
//   for (let i = 0; i < 8; i++) {
//     result += characters.charAt(Math.floor(Math.random() * charactersLength));
//   }
//   return result;
// };
//
// const redisExample = async () => {
//   const redis = require('redis');
//   const client = redis.createClient({
//     host: 'redistracertest.teqpqr.ng.0001.usw2.cache.amazonaws.com',
//     port: '6379',
//   });
//   const getAsync = promisify(client.get).bind(client);
//   const setAsync = promisify(client.set).bind(client);
//
//   const randomKey = `key_${randomId()}`;
//   const randomValue = {
//     name: `name_${randomId()}`,
//     dummy: `dummy_${randomId()}`,
//   };
//
//   console.log('About to set', { key: randomKey, value: randomValue });
//   await setAsync(randomKey, JSON.stringify(randomValue));
//
//   console.log('About to get', { key: randomKey });
//   const getResult = await getAsync(randomKey);
//   console.log('get op done', JSON.parse(getResult));
// };

// const asyncQueryByCallback = (pgClient, query) =>
//   new Promise((resolve, reject) => {
//     pgClient.query(query, (err, res) => {
//       err && reject(err);
//       !err && resolve(res);
//     });
//   });
//
// const pgExmaple = async () => {
//   const { Client } = require('pg');
//   const client = new Client({
//     host: 'database-1-instance-1.ci1gryl59yfu.us-west-1.rds.amazonaws.com',
//     port: 5432,
//     user: 'postgres',
//     password: 'postgres',
//   });
//   await client.connect();
//   try {
//     const asyncRes = await client.query(
//       "select * from information_schema.sql_languages where information_schema.sql_languages.sql_language_year='$0'",
//       ['2003']
//     );
//   } catch (e) {
//     console.log('PASS');
//   }
//   const asyncRes = await client.query(
//     'select * from information_schema.sql_languages where information_schema.sql_languages.sql_language_year=$1',
//     ['2003']
//   );
//   const callbackRes = await asyncQueryByCallback(client, 'SELECT NOW()');
//   console.log('pg res (callback)', callbackRes);
//   console.log('pg res (async)', asyncRes);
// };
//
// const pgPoolExmaple = async () => {
//   const NativeClient = require('pg').Client;
//   const Pool = require('pg-pool');
//   const pool = new Pool({
//     host: 'database-1-instance-1.ci1gryl59yfu.us-west-1.rds.amazonaws.com',
//     port: 5432,
//     user: 'postgres',
//     password: 'postgres',
//     Client: NativeClient,
//   });
//   const client = await pool.connect();
//   try {
//     const asyncRes = await client.query(
//       "select * from information_schema.sql_languages where information_schema.sql_languages.sql_language_year='$0'",
//       ['2003']
//     );
//   } catch (e) {
//     console.log('PASS');
//   }
//   const asyncRes = await client.query(
//     'select * from information_schema.sql_languages where information_schema.sql_languages.sql_language_year=$1',
//     ['2003']
//   );
//   const callbackRes = await asyncQueryByCallback(client, 'SELECT NOW()');
//   console.log('pg res (callback)', callbackRes);
//   console.log('pg res (async)', asyncRes);
// };

// const invokeFunctionFuncTest = async (invokeFunction = false) => {
//   if (!invokeFunction) {
//     const axios = require('axios');
//     await axios.get('https://www.google.com');
//   } else {
//     console.log('1');
//     const AWS = require('aws-sdk');
//     const lambda = new AWS.Lambda();
//     const params = {
//       FunctionName: 'aws-nodejs-dev-web-pack-child',
//       Payload: '{}',
//     };
//     await lambda.invoke(params).promise();
//     console.log('2');
//   }
// };

// const graphQl = async () => {
//   const { request, gql } = require('graphql-request');
//
//   const query = gql`
//     {
//       Country {
//         name
//       }
//     }
//   `;
//
//   const result = await request('https://countries-274616.ew.r.appspot.com/', query);
//   console.log('GraphQL Result', result);
// };

// const axiosRetry = async () => {
//   const axiosRetry = require('axios-retry');
//   const axios = require('axios');
//
//   axiosRetry(axios, {
//     retries: 3,
//     retryCondition: e => {
//       console.log(e);
//       console.log('E.Code', e.code);
//       return true;
//     },
//   });
//
//   await axios.post(beeceptorUrl, {
//     firstName: 'Fred',
//     lastName: 'Flintstone',
//   });
// };

// const rax = require('retry-axios');
// const axios = require('axios');
// const interceptorId = rax.attach();
// const retryAxios = async () => {
//   await axios.post(
//     beeceptorUrl,
//     {
//       firstName: 'Fred',
//       lastName: 'Flintstone',
//     },
//     {
//       raxConfig: {
//         statusCodesToRetry: [[1, 1000]],
//         httpMethodsToRetry: ['POST'],
//       },
//     }
//   );
//   console.log(interceptorId);
// };

// const gaxios = async () => {
//   const { request } = require('gaxios');
//   const res = await request({
//     url: beeceptorUrl,
//     method: 'POST',
//     body: JSON.stringify({
//       firstName: 'Efi',
//     }),
//   });
//   console.log(res);
// };

// const nodeFetchRetry = async () => {
//   const fetch = require('@adobe/node-fetch-retry');
//   const response = await fetch(beeceptorUrl, {
//     retryOnHttpResponse: () => true,
//     retryMaxDuration: 6000,
//   });
//   console.log(response);
// };
//
// const createWaiterFor = (times, resolve) => {
//   let c = 0;
//   return () => {
//     c++;
//     if (c >= times) {
//       resolve();
//     }
//   };
// };
//

//TODO: MYSQL

// const mysql2Test = () =>
//   new Promise(resolve => {
//     const triggerWait = createWaiterFor(3, resolve);
//
//     const mysql = require('mysql2');
//
//     // create the connection to database
//     const connection = mysql.createConnection({
//       host: 'mysql-tracer-db.ci1gryl59yfu.us-west-1.rds.amazonaws.com',
//       user: 'admin',
//       password: 'Az123456',
//       database: 'TracerTestDB',
//     });
//
//     // simple query
//     connection.query('SELECT * FROM `Users`', function findMe(err, results) {
//       console.log('Error 1', err);
//       console.log('Result 1', results);
//       triggerWait();
//     });
//
//     // with placeholder
//     connection.query('SELECT * FROM `Users` WHERE `favLang` = ?', ['Java'], function findMe(
//       err,
//       results
//     ) {
//       console.log('Error 2', err);
//       console.log('Result 2', results);
//       triggerWait();
//     });
//
//     connection.execute('SELECT * FROM `Users` WHERE `favLang` = ?', ['Java'], function findMe(
//       err,
//       results
//     ) {
//       console.log('Error 2', err);
//       console.log('Result 2', results);
//       triggerWait();
//     });
//   });
//
// const mysqlTest = () =>
//   new Promise(resolve => {
//     const triggerWait = createWaiterFor(2, resolve);
//     const mysql = require('mysql');
//
//     // create the connection to database
//     const connection = mysql.createConnection({
//       host: 'mysql-tracer-db.ci1gryl59yfu.us-west-1.rds.amazonaws.com',
//       user: 'admin',
//       password: 'Az123456',
//       database: 'TracerTestDB',
//     });
//     connection.connect();
//
//     // simple query
//     connection.query('SELECT * FROM `Users`', function findMe(err, results) {
//       console.log('Error 1', err);
//       console.log('Result 1', results);
//       triggerWait();
//     });
//
//     // with placeholder
//     connection.query('SELECT * FROM `Users` WHERE `favLang` = ?', ['Java'], function findMe(
//       err,
//       results
//     ) {
//       console.log('Error 2', err);
//       console.log('Result 2', results);
//       triggerWait();
//     });
//   });

//TODO: SQL SERVER
//
// const sqlServers = async () => {
//   const sql = require('mssql');
//   console.log('sql', sql);
//   const sqlPath = require.resolve('mssql');
//   console.log('SQLPATH', sqlPath);
//   console.log('SQLPATH end');
//
//   const manualPromisedMssql = sql =>
//     new Promise(resolve => {
//       sql.query(`select * from Users`, (arg0, arg1) => {
//         console.log('Result from client', { arg0, arg1 });
//         resolve('OK');
//       });
//     });
//
//   const manualPromisedMssqlWithError = sql =>
//     new Promise(resolve => {
//       sql.query(`select * from UsersSSSS`, (arg0, arg1) => {
//         console.log('Result from client', { arg0, arg1 });
//         resolve('OK');
//       });
//     });
//
//   const queryWithParams = async sql => {
//     const req = new sql.Request();
//     req.input('t1', sql.VarChar(50), 'Users');
//     return req.query('select * from Users where name = @t1');
//   };
//
//   const simpleFlowQuery = async sql => {
//     return await sql.query(`select * from USSSSsers`).catch(e => {
//       console.log('Catch');
//       console.log(e);
//     });
//   };
//   await sql.connect(
//     'mssql://testUser:testUser1@mssql-16055-0.cloudclusters.net:16055/TestDB?encrypt=true'
//   );
//   console.log('## Simple flow');
//   await manualPromisedMssqlWithError(sql);
//   // await simpleFlowQuery(sql).catch(error => console.log('Error From catch2', error));
//   console.log('## Simple flow - done');
//
//   // console.log('## Params flow');
//   // await queryWithParams(sql);
//   // console.log('## Params flow - done');
//
//   // console.log('## Callback flow');
//   // await manualPromisedMssql(sql);
//   // await manualPromisedMssqlWithError(sql);
//   console.log('## Callback flow - done');
// };

// const sqlServerLWB = async () => {
//   const {ConnectionPool} = require('mssql');
//   const config = {
//     user: 'admin',
//     password: 'Az1234567',
//     server: "test-db.cidxumlohsat.us-west-2.rds.amazonaws.com",
//     // server: "52.27.208.71",
//     multiSubnetFailover: true,
//     enableArithAbort: true
//   };
//   const pool = await new ConnectionPool(config).connect();
//
//   console.log("Using pool");
//   return pool.request().query`SELECT CURRENT_TIMESTAMP; SELECT CURRENT_TIMESTAMP; SELECT CURRENT_TIMESTAMP; SELECT CURRENT_TIMESTAMP; SELECT CURRENT_TIMESTAMP; SELECT CURRENT_TIMESTAMP`;
// };
//
// function sleep(ms) {
//   return new Promise((resolve) => {
//     setTimeout(resolve, ms);
//   });
// }
// //
// const writeToDDB = async () => {
//   const AWS = require('aws-sdk');
//   const ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
//
// const  params = {
//   TableName: 'CUSTOMER_LIST',
//   Item: {
//     'CUSTOMER_ID' : {N: '001'},
//     'CUSTOMER_NAME' : {S: 'Richard Roe'}
//   }
// };
//
//   await ddb.putItem(params).promise().catch(() => {});
// }
//
// const parrlerAxiosRequests = async () => {
//   const axios = require('axios');
//   // await dynamoDbRequests()
//   // await Promise.all([
//   //   axios.get('https://parallel-test.free.beeceptor.com'),
//   //   axios.get('https://parallel-test1.free.beeceptor.com'),
//   //   axios.get('https://parallel-test2.free.beeceptor.com')
//   // ]);
//   // await sleep(5000)
//   // await Promise.all([
//   //   axios.get('https://parallel-test.free.beeceptor.com'),
//   //   axios.get('https://parallel-test1.free.beeceptor.com'),
//   //   axios.get('https://parallel-test2.free.beeceptor.com')
//   // ]);
//   // await sleep(5000)
//   await Promise.all([
//     axios.get('https://parallel-test.free.beeceptor.com'),
//     // axios.get('https://parallel-test1.free.beeceptor.com'),
//     // axios.get('https://parallel-test2.free.beeceptor.com')
//   ]);
//   // await sleep(5000)
// }


const childFn = (event, context) => dynamoDbRequests();

const handler = lumigo.trace(childFn);
exports.handler = handler;