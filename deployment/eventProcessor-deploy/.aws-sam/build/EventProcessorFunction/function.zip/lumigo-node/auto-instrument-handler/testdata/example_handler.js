module.exports.my_handler = () => ({ hello: 'world' });
