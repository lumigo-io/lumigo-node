//We need to mock this function do not lose ref to the user result
module.exports = o => o;
