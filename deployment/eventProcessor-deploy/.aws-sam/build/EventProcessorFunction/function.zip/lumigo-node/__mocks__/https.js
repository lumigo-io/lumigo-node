const { HttpsMocker } = require('../testUtils/httpsMocker');
module.exports = HttpsMocker;
