export interface HttpInfo {
  host: string;
  request: any;
  response: any;
}
