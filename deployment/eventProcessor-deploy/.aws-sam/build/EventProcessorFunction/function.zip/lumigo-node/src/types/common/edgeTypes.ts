export interface EdgeUrl {
  host;
  path: string;
  url: string;
}
